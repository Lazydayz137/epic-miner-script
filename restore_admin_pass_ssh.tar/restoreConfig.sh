#!/bin/sh
echo -e "admin\nadmin" | passwd
